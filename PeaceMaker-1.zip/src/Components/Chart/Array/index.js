import React from 'react'

const ArrayData = () => {
    const data =[
        { name:"Spiritual" ,value:2000000000},
        { name:"Mental" ,value:2000000000},
        { name:"Emotionally" ,value:2000000000},
        { name:"Social" ,value:2000000000},
        { name:"Physically" ,value:2000000000},
    ]
  return (
    <div>ArrayData</div>
  )
}

export default ArrayData