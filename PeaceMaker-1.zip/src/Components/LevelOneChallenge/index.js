import React from 'react'

const LevelOneChallenge = () => {
  return (
    <div>LevelOneChallenge</div>
  )
}

export default LevelOneChallenge