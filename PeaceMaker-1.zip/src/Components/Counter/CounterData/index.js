const CounterData = [

    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },
    {
        num: '1',
        level: 'Level One',
        comp: '0 / 7 Completed'
    },

]

export default CounterData; 