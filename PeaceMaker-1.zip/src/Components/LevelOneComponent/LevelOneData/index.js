const LevelOneData = [
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
                <p> Points:</p><h6>1 Day Point </h6>
               
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
                <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
                 <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
                 <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
              <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
               <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
               <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
                <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },

    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
               <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
              <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
              <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },
    {

        level: <h4>Find 7 Yellow Buttons</h4>,
        comp:
            <div className="d-flex">
                <p>Duration:</p><h6>1 Day</h6>
            </div>
        ,
        comp_2:
            <div className="d-flex">
               <p> Points:</p><h6>1 Day Point </h6>
            </div>
    },

]

export default LevelOneData; 