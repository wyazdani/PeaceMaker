import React from "react";
import { Col, Row } from "react-bootstrap";

const Profile = () => {
  return 
  <>
    <Row>
      <Col md={6}>hjk</Col>
      <Col md={6}>rtyu</Col>
    </Row>
  </>;
};

export default Profile;
